//
//  UICButton.h
//  UICEditSDK
//
//  Created by Cc on 15/2/12.
//  Copyright (c) 2015年 PinguoSDK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICButton : UIButton

- (void)pSetupTitle:(NSString*)text;

@end
