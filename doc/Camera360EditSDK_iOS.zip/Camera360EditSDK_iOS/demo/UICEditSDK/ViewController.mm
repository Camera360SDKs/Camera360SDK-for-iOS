//
//  ViewController.m
//  UICEditSDK
//
//  Created by Cc on 14/12/11.
//  Copyright (c) 2014年 PinguoSDK. All rights reserved.
//

#import "ViewController.h"
#import <PhotoEditFramework/PhotoEditFramework.h>
#import "UICDisplayImageView.h"

@interface ViewController () <UINavigationControllerDelegate
    ,UIImagePickerControllerDelegate
    ,pg_edit_sdk_controller_delegate>

@property (nonatomic,weak) IBOutlet UICDisplayImageView *mDisplayImageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Button
- (IBAction)onLoadImageButtonClick:(id)sender
{
    [self pPresentAUIImagePickerController];
}

#pragma mark - UIImagePickerController
- (void)pPresentAUIImagePickerController
{
    if ([UIImagePickerController isSourceTypeAvailable:(UIImagePickerControllerSourceTypePhotoLibrary)]) {
        
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        picker.delegate = self;
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        //model 一个 View
        [self presentViewController:picker animated:YES completion:^{
            
            NSLog(@"选择照片..");
        }];
    }
    else {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"访问图片库失败"
                                                        message:@"是否关闭了访问相册的系统设置"
                                                       delegate:nil
                                              cancelButtonTitle:@"了解"
                                              otherButtonTitles:nil];
        [alert show];
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info valueForKey:UIImagePickerControllerOriginalImage];
    NSAssert(image, @" ");
    if (image) {
        
        [self.mDisplayImageView pSetupOrigImage:image];
        
        __weak __typeof (&*self)weakSelf = self;
        [picker dismissViewControllerAnimated:YES completion:^{
            //启动编辑UI
            [weakSelf pPushPGEditSDKController];
        }];
    }
    
}


#pragma mark - pg_edit_sdk_controller
- (void)pPushPGEditSDKController
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    pg_edit_sdk_controller *editCtl = [self pCreatePGEditSDKController];
    NSAssert(editCtl, @" ");
    if (editCtl) {
        
        [self.navigationController pushViewController:editCtl animated:YES];
    }
}
- (pg_edit_sdk_controller*)pCreatePGEditSDKController
{
    //构建编辑对象
    pg_edit_sdk_controller_object *obje = [[pg_edit_sdk_controller_object alloc] init];
    {
        //传入照片
        obje.pCSA_fullImage = [self.mDisplayImageView.mOrigImage copy];
    }
    pg_edit_sdk_controller *editCtr = [[pg_edit_sdk_controller alloc] initWithEditObject:obje
                                                                            withDelegate:self];
    return editCtr;
}

- (void)dgPhotoEditingViewControllerDidCancel:(UIViewController *)pController
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)dgPhotoEditingViewControllerDidFinish:(UIViewController *)pController
                                       object:(pg_edit_sdk_controller_object *)pOjbect
{
    UIImage *image = [UIImage imageWithData:pOjbect.pOutEffectDisplayData];
    NSAssert(image, @" ");
    [self.mDisplayImageView pSetupPreviewImage:image];
    [self.navigationController popViewControllerAnimated:YES];
}
@end
