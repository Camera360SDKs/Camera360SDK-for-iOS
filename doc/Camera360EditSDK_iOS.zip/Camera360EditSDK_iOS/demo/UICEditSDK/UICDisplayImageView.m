//
//  UICDisplayImageView.m
//  UICEditSDK
//
//  Created by Cc on 14/12/11.
//  Copyright (c) 2014年 PinguoSDK. All rights reserved.
//

#import "UICDisplayImageView.h"
#import <pg_edit_sdk_common/pg_edit_sdk_common.h>

@interface UICDisplayImageView ()

//原始图
@property (nonatomic,strong) UIImage *mOrigImage;

//原始缩略图
@property (nonatomic,strong) UIImage *mOrigPreviewImage;

//编辑后效果图
@property (nonatomic,strong) UIImage *mPreviewImage;

@property (nonatomic,assign) BOOL     mIsShowOrigImage;

@end

@implementation UICDisplayImageView

- (void)awakeFromNib
{
    self.userInteractionEnabled = YES;
    self.mIsShowOrigImage = NO;
}

- (void)pSetupOrigImage:(UIImage *)image
{
    self.mOrigImage = image;
    {
        CGFloat w = self.frame.size.width;
        CGFloat h = w / (image.size.width / image.size.height);
        self.mOrigPreviewImage = [image c_ResizedImage:CGSizeMake(w, h) interpolationQuality:(kCGInterpolationDefault)];
    }
    [self pSetupPreviewImage:nil];
}

- (void)pSetupPreviewImage:(UIImage *)image
{
    self.mPreviewImage = image;
    [self pUpdateDisplay];
}

- (void)pUpdateDisplay
{
    __weak __typeof (&*self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (weakSelf.mIsShowOrigImage) {
            
            [weakSelf setImage:weakSelf.mOrigPreviewImage];
        }
        else {
            
            if (weakSelf.mPreviewImage) {
                
                [weakSelf setImage:weakSelf.mPreviewImage];
            }
            else {
                
                [weakSelf setImage:weakSelf.mOrigPreviewImage];
            }
        }
    });
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"显示 原图");
    self.mIsShowOrigImage = YES;
    [self pUpdateDisplay];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"显示 编辑后效果图");
    self.mIsShowOrigImage = NO;
    [self pUpdateDisplay];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"显示 编辑后效果图");
    self.mIsShowOrigImage = NO;
    [self pUpdateDisplay];
}
@end
