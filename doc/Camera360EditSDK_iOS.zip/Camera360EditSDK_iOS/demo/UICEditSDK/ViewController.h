//
//  ViewController.h
//  UICEditSDK
//
//  Created by Cc on 14/12/11.
//  Copyright (c) 2014年 PinguoSDK. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
